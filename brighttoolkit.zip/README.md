![BrightToolkit](https://github.com/hou80houzhu/brighttoolkit/raw/master/images/logo.png) 

Chrome Develop Toolkit for AxesJS Projects

[Install BrightToolkit chrome extension](https://chrome.google.com/webstore/detail/brighttoolkit/nlnogndclkgmlkdlicieaonmggfapbgf "Install BrightToolkit chrome extension")
