![BrightToolkit](https://github.com/hou80houzhu/axestoolkit/raw/master/images/logo.png) 

Chrome Develop Toolkit for AxesJS Projects

[Install BrightToolkit chrome extension](https://chrome.google.com/webstore/detail/axestoolkit/acjkahlifejkmhoibcmjekbmhpagbclm "Install BrightToolkit chrome extension")
